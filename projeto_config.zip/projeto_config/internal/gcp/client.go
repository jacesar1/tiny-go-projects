package gcp

import (
	"fmt"
	"os/exec"
)

// GetCurrentProject retorna o projeto padrão configurado no gcloud
func GetCurrentProject() (string, error) {
	cmd := exec.Command(
		"gcloud",
		"config", "get-value", "project",
	)

	output, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("erro ao obter projeto atual: %w", err)
	}

	// Remove quebra de linha do final
	return string(output[:len(output)-1]), nil
}

// GetCurrentAccount retorna a conta autenticada no gcloud
func GetCurrentAccount() (string, error) {
	cmd := exec.Command(
		"gcloud",
		"config", "get-value", "account",
	)

	output, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("erro ao obter conta atual: %w", err)
	}

	// Remove quebra de linha do final
	return string(output[:len(output)-1]), nil
}

// ValidateAuthentication verifica se o usuário está autenticado no GCP
func ValidateAuthentication() error {
	_, err := GetCurrentAccount()
	if err != nil {
		return fmt.Errorf("usuário não autenticado no GCP. Por favor, execute: gcloud auth login")
	}
	return nil
}
