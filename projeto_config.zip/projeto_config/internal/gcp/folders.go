package gcp

import (
	"encoding/json"
	"fmt"
	"os/exec"
	"strings"
)

// CreateFolder cria uma pasta no Resource Manager do GCP
// Retorna o folder ID da pasta criada
func CreateFolder(parentFolderID, displayName string) (string, error) {
	// Comando: gcloud resource-manager folders create --display-name=<name> --organization=<org-id>
	// Ou: gcloud resource-manager folders create --display-name=<name> --parent=folders/<folder-id>

	cmd := exec.Command(
		"gcloud",
		"resource-manager", "folders", "create",
		fmt.Sprintf("--display-name=%s", displayName),
		fmt.Sprintf("--parent=folders/%s", parentFolderID),
		"--format=json",
	)

	output, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("erro ao criar pasta %s: %w\nOutput: %s", displayName, err, output)
	}

	// Parse do JSON retornado
	var result map[string]interface{}
	if err := json.Unmarshal(output, &result); err != nil {
		return "", fmt.Errorf("erro ao fazer parse do resultado: %w", err)
	}

	folderID, ok := result["name"].(string)
	if !ok {
		return "", fmt.Errorf("não foi possível extrair folder ID da resposta")
	}

	// O resultado vem como "folders/123456", precisamos extrair só o número
	parts := strings.Split(folderID, "/")
	if len(parts) == 2 {
		folderID = parts[1]
	}

	return folderID, nil
}

// ListFolders lista as pastas dentro de uma pasta pai
func ListFolders(parentFolderID string) ([]map[string]interface{}, error) {
	cmd := exec.Command(
		"gcloud",
		"resource-manager", "folders", "list",
		fmt.Sprintf("--parent=folders/%s", parentFolderID),
		"--format=json",
	)

	output, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("erro ao listar pastas: %w", err)
	}

	var folders []map[string]interface{}
	if err := json.Unmarshal(output, &folders); err != nil {
		return nil, fmt.Errorf("erro ao fazer parse das pastas: %w", err)
	}

	return folders, nil
}
