package gcp

import (
	"fmt"
	"os/exec"
)

// EnableAPI habilita uma API em um projeto GCP
func EnableAPI(projectID, apiName string) error {
	// Comando: gcloud services enable <api-name> --project=<project-id>
	cmd := exec.Command(
		"gcloud",
		"services", "enable", apiName,
		fmt.Sprintf("--project=%s", projectID),
	)

	output, err := cmd.Output()
	if err != nil {
		return fmt.Errorf("erro ao habilitar API %s no projeto %s: %w\nOutput: %s", apiName, projectID, err, output)
	}

	return nil
}

// EnableAPIs habilita múltiplas APIs em um projeto
func EnableAPIs(projectID string, apiNames []string) error {
	for _, apiName := range apiNames {
		if err := EnableAPI(projectID, apiName); err != nil {
			return err
		}
	}
	return nil
}

// GetRequiredAPIs retorna as APIs necessárias
func GetRequiredAPIs() []string {
	return []string{
		"compute.googleapis.com",           // Compute Engine
		"servicenetworking.googleapis.com", // Service Networking
	}
}
