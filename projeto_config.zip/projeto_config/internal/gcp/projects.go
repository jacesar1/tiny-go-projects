package gcp

import (
	"encoding/json"
	"fmt"
	"os/exec"
)

// CreateProject cria um novo projeto GCP dentro de uma pasta
func CreateProject(projectID, displayName, parentFolderID string) (string, error) {
	// Comando: gcloud projects create <project-id> --name=<display-name> --folder=<folder-id>
	cmd := exec.Command(
		"gcloud",
		"projects", "create", projectID,
		fmt.Sprintf("--name=%s", displayName),
		fmt.Sprintf("--folder=%s", parentFolderID),
		"--format=json",
	)

	output, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("erro ao criar projeto %s: %w\nOutput: %s", projectID, err, output)
	}

	// Parse do JSON retornado
	var result map[string]interface{}
	if err := json.Unmarshal(output, &result); err != nil {
		return "", fmt.Errorf("erro ao fazer parse do resultado: %w", err)
	}

	createdProjectID, ok := result["projectId"].(string)
	if !ok {
		return "", fmt.Errorf("não foi possível extrair project ID da resposta")
	}

	return createdProjectID, nil
}

// SetProjectLabels adiciona labels a um projeto GCP
func SetProjectLabels(projectID string, labels map[string]string) error {
	// Monta o parametro de labels
	labelsStr := ""
	for key, value := range labels {
		if labelsStr != "" {
			labelsStr += ","
		}
		labelsStr += fmt.Sprintf("%s=%s", key, value)
	}

	cmd := exec.Command(
		"gcloud",
		"projects", "update", projectID,
		fmt.Sprintf("--update-labels=%s", labelsStr),
	)

	output, err := cmd.Output()
	if err != nil {
		return fmt.Errorf("erro ao adicionar labels ao projeto %s: %w\nOutput: %s", projectID, err, output)
	}

	return nil
}
