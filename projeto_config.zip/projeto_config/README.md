# Projeto Config - Automação de Projetos GCP

Aplicação Go para automatizar a criação de projetos no GCP seguindo a estrutura definida pela Eletrobras.

## 📋 Pré-requisitos

- **Go** 1.16+
- **gcloud CLI** instalado e configurado
- Autenticação no GCP: `gcloud auth login`

## 🚀 Instalação e Setup

### 1. Inicializar o projeto Go

```bash
cd projeto_config
go mod tidy
```

### 2. Executar a aplicação

```bash
# Passo 1 - Criar estrutura de pastas
go run main.go -project benner-cloud

# Ou especificar um passo específico
go run main.go -project benner-cloud -step 1

# Com opções customizadas
go run main.go -project benner-cloud -org-id 727440331682 -parent-folder fldr-scge
```

## 📚 Passos de Automação

### Passo 1: Criar Pastas no Resource Manager ✅
Cria a seguinte estrutura:
```
fldr-<nome do projeto>/
├── fldr-dev/
│   └── elet-<nome do projeto>-dev
├── fldr-qld/
│   └── elet-<nome do projeto>-qld
└── fldr-prd/
    └── elet-<nome do projeto>-prd
```

**Comando:**
```bash
go run main.go -project benner-cloud -step 1
```

### Passo 2: Adicionar Labels (Em desenvolvimento)
Adiciona os seguintes labels a cada projeto:
- `ambiente`: dev | qld | prd
- `companhia`: elet
- `projeto`: <nome do projeto>

### Passo 3: Habilitar APIs (Em desenvolvimento)
Habilita as seguintes APIs em cada projeto:
- Compute Engine
- Service Networking

### Passo 4: Atachar nas Redes Spokes (Em desenvolvimento)
Associa cada projeto à VPC spoke do seu ambiente.

## 📂 Estrutura do Projeto

```
projeto_config/
├── main.go                          # Entrada principal
├── go.mod                           # Dependências do Go
├── cmd/                             # Comandos CLI
├── internal/
│   ├── gcp/                        # Operações GCP
│   │   ├── client.go               # Cliente GCP (auth, config)
│   │   ├── folders.go              # Gerenciamento de pastas
│   │   ├── projects.go             # Gerenciamento de projetos
│   │   ├── apis.go                 # Gerenciamento de APIs
│   │   └── step1_folders.go        # Orquestrador do Passo 1
│   ├── models/                     # Estruturas de dados
│   │   └── types.go                # Tipos do projeto
│   └── config/                     # Configurações
└── README.md
```

## 🔧 Exemplos de Uso

### Criar projeto com nome "benner-cloud"
```bash
go run main.go -project benner-cloud
```

### Usar pasta pai diferente
```bash
go run main.go -project benner-cloud -parent-folder fldr-outroprojeto
```

### Executar apenas um passo específico
```bash
go run main.go -project benner-cloud -step 2
```

## 🛠️ Desenvolvimento

### Próximos passos
- [ ] Implementar Passo 2 - Adicionar labels
- [ ] Implementar Passo 3 - Habilitar APIs
- [ ] Implementar Passo 4 - Atachar nas redes spokes
- [ ] Adicionar testes unitários
- [ ] Adicionar sistema de logging mais robusto
- [ ] Criar arquivo de configuração YAML/JSON

## 📝 Notas

- Os parâmetros de organização e pasta pai têm valores padrão
- Certifique-se de estar autenticado no GCP antes de executar
- Os nomes de projeto serão validados conforme as convenções do GCP
